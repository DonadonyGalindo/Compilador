/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica2lfp;

/**
 *
 * @author Denisse
 */
public enum Token {
  ID, INT, ERROR, CADENA, PALABRARESERVADA, SIGNODIVISION, SIGNOPOR, SIGNOMAS, SIGNOMENOS, PARENTECISABIERTO, PARENTECISCERRADO, LLAVEABIERTO, LLAVECERRADO, PUNTOYCOMA, CORCHETEABIERTO, CORCHETECERRADO, IGUAL, COMA, PUNTO,FUNCIONRESERVADA
}
